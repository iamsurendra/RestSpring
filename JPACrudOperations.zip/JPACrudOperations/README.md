##Please run the below DDL query before you execute this application.  

CREATE TABLE students
(studentid NUMBER(6) PRIMARY KEY,
name VARCHAR2(25));
