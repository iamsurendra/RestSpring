##Please run the below DDL query before you execute this application.  

CREATE TABLE Author 
(authorId NUMBER(6) PRIMARY KEY,
firstName VARCHAR2(25),middleName VARCHAR2(25),lastName VARCHAR2(25),phoneNo VARCHAR2(25));
